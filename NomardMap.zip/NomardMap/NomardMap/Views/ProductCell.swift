//
//  ProductCell.swift
//  NomardMap
//
//  Created by 정다인 on 2023/03/14.
//

import UIKit

class ProductCell: UICollectionViewCell {
    
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var productNameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
}
